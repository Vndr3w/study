# My Own Collection

## Description
This collection contains custom Ansible modules and roles.

## Modules
- **my_own_module**: Creates a text file on remote host

## Roles
- **my_file_creator**: Role that creates a file using custom module

## Usage
```yaml
- hosts: localhost
  roles:
    - my_file_creator
```

## License
GPL-3.0-or-later
